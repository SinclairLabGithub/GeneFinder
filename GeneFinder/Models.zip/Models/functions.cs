﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeneFinder.Models
{
    class functions
    {
        public static string ReverseComplement(string seq)
        {
            char[] seqInv = seq.ToArray<char>();
            Array.Reverse(seqInv);
            for (int i = 0; i < seqInv.Length; i++)
            {
                if (seqInv[i] == 'A')
                {
                    seqInv[i] = 'T';
                }
                else if (seqInv[i] == 'C')
                {
                    seqInv[i] = 'G';
                }
                else if (seqInv[i] == 'G')
                {
                    seqInv[i] = 'C';
                }
                else if (seqInv[i] == 'T')
                {
                    seqInv[i] = 'A';
                }
            }
            return new string(seqInv);
        }
        public static string CodonToAminoacid(string c)
        {
            switch (c)
            {
                case "TTT": return "F";
                case "TTC": return "F";
                case "TTA": return "L";
                case "TTG": return "L";
                case "CTT": return "L";
                case "CTC": return "L";
                case "CTA": return "L";
                case "CTG": return "L";
                case "ATT": return "I";
                case "ATC": return "I";
                case "ATA": return "I";
                case "ATG": return "M";
                case "GTT": return "V";
                case "GTC": return "V";
                case "GTA": return "V";
                case "GTG": return "V";
                case "TCT": return "S";
                case "TCC": return "S";
                case "TCA": return "S";
                case "TCG": return "S";
                case "CCT": return "P";
                case "CCC": return "P";
                case "CCA": return "P";
                case "CCG": return "P";
                case "ACT": return "T";
                case "ACC": return "T";
                case "ACA": return "T";
                case "ACG": return "T";
                case "GCT": return "A";
                case "GCC": return "A";
                case "GCA": return "A";
                case "GCG": return "A";
                case "TAT": return "Y";
                case "TAC": return "Y";
                case "TAA": return "*";//STOP
                case "TAG": return "*";//STOP
                case "CAT": return "H";
                case "CAC": return "H";
                case "CAA": return "Q";
                case "CAG": return "Q";
                case "AAT": return "N";
                case "AAC": return "N";
                case "AAA": return "K";
                case "AAG": return "K";
                case "GAT": return "D";
                case "GAC": return "D";
                case "GAA": return "E";
                case "GAG": return "E";
                case "TGT": return "C";
                case "TGC": return "C";
                case "TGA": return "*";//STOP
                case "TGG": return "W";
                case "CGT": return "R";
                case "CGC": return "R";
                case "CGA": return "R";
                case "CGG": return "R";
                case "AGT": return "S";
                case "AGC": return "S";
                case "AGA": return "R";
                case "AGG": return "R";
                case "GGT": return "G";
                case "GGC": return "G";
                case "GGA": return "G";
                case "GGG": return "G";

            }
            return "INCORRECT CODON " + c;
        }
        public static string DNAToProtein(string c)
        {
            string aminoacid = "";
            int length = (c.Length / 3);
            for (int i = 0; i < length; i++)
            {
                string codon = "" + c.ElementAt(i * 3 + 0) + c.ElementAt(i * 3 + 1) + c.ElementAt(i * 3 + 2);
                aminoacid += CodonToAminoacid(codon);
            }
            return aminoacid;
        }
        public static char[] LoadFasta(string file)
        {
            string annotation = File.ReadAllText(file);
            annotation = annotation.Substring(annotation.IndexOf("\n"));
            annotation = annotation.Replace("\n", "");
            annotation = annotation.ToUpper();
            return annotation.ToCharArray();
        }

    }
}
