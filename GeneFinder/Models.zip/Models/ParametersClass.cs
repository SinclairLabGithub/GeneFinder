﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeneFinder.Models
{
    public class ParametersClass
    {
        public List<string> startCodons { get; set; }
        public List<string> stopCodons { get; set; }
        public int minLenght { get; set; }
        public int maxLenght { get; set; }
        public int similarity { get; set; }
        public bool allowChange { get; set; }
        public string specie1 { get; set; }
        public string specie2 { get; set; }
        public string specie3 { get; set; }
        public string specie1Red { get; set; }
        public string specie2Red { get; set; }
        public string specie3Red { get; set; }
        public double ta { get; set; }
        public double tb { get; set; }
        public double tc { get; set; }
        public double td { get; set; }
        public double cutoff { get; set; }
        public string genomeFolder { get; set; }
        public string annotationFolder { get; set; }
        public string conservationFolder { get; set; }
        public List<string> genomeFiles { get; set; }
        public string indexFile { get; set; }
        public int indexWindowSize { get; set; }
        public List<string> kozaks { get; set; }
        public int basesToCheck { get; set; }
        public float conservationThreshold { get; set; }
        public List<string> conditionsName { get; set; }
        public bool extracted { get; set; }
        public bool classified { get; set; }
        public bool realigned { get; set; }
        public bool annotated { get; set; }
        public bool conditions { get; set; }
        public bool temporalFile { get; set; }
        public string version { get; set; }

        public ParametersClass()
        {
            startCodons = new List<string>();
            stopCodons = new List<string>();
            minLenght = 30;
            maxLenght = 300;
            allowChange = true;
            ta = 0.039953;
            tb = 0.009168;
            tc = 0.007501;
            td = 0.026355;
            cutoff = 0.2;
            genomeFiles = new List<string>();
            indexFile = "";
            genomeFolder = "";
            annotationFolder = "";
            conservationFolder = "";
            indexWindowSize = 23;
            kozaks = new List<string>();
            basesToCheck = 90;
            conservationThreshold = (float)2.0 / (float)10.0;
            conditionsName = new List<string>();
            extracted = false;
            classified = false;
            realigned = false;
            annotated = false;
            conditions = false;
            version = "1";
        }

        internal void AddFileHeader(System.IO.StreamWriter outputStream)
        {
            outputStream.WriteLine("Version");
            outputStream.WriteLine(version);
            outputStream.WriteLine("Extracted");
            outputStream.WriteLine(extracted);
            outputStream.WriteLine("Classified");
            outputStream.WriteLine(classified);
            outputStream.WriteLine("Realigned");
            outputStream.WriteLine(realigned);
            outputStream.WriteLine("Annotated");
            outputStream.WriteLine(annotated);
            outputStream.WriteLine("Condition");
            outputStream.WriteLine(conditions);
            outputStream.WriteLine("Start Codons Number");
            outputStream.WriteLine(startCodons.Count);
            foreach(var salida in startCodons)
            {
                outputStream.WriteLine(salida);
            }
            outputStream.WriteLine("Stop Codons Number");
            outputStream.WriteLine(stopCodons.Count);
            foreach (var salida in stopCodons)
            {
                outputStream.WriteLine(salida);
            }
            outputStream.WriteLine("Min length");
            outputStream.WriteLine(minLenght);
            outputStream.WriteLine("Max length");
            outputStream.WriteLine(maxLenght);
            outputStream.WriteLine("TA");
            outputStream.WriteLine(ta);
            outputStream.WriteLine("TB");
            outputStream.WriteLine(tb);
            outputStream.WriteLine("TC");
            outputStream.WriteLine(tc);
            outputStream.WriteLine("TD");
            outputStream.WriteLine(td);
            outputStream.WriteLine("Conservation Cutoff");
            outputStream.WriteLine(cutoff);
            outputStream.WriteLine("Genomefiles Number");
            outputStream.WriteLine(genomeFiles.Count);
            foreach (var salida in genomeFiles)
            {
                outputStream.WriteLine(salida);
            }
            outputStream.WriteLine("Index File");
            outputStream.WriteLine(indexFile);
            outputStream.WriteLine("Genome Folder");
            outputStream.WriteLine(genomeFolder);
            outputStream.WriteLine("Annotation Folder");
            outputStream.WriteLine(annotationFolder);
            outputStream.WriteLine("Conservation Folder");
            outputStream.WriteLine(conservationFolder);
            outputStream.WriteLine("Index Windows Size");
            outputStream.WriteLine(indexWindowSize);
            outputStream.WriteLine("Kozaks Number");
            outputStream.WriteLine(kozaks.Count());
            foreach (var salida in kozaks)
            {
                outputStream.WriteLine(salida);
            }
            outputStream.WriteLine("Bases to check");
            outputStream.WriteLine(basesToCheck);
            outputStream.WriteLine("Conservation Threshold");
            outputStream.WriteLine(conservationThreshold);
            outputStream.WriteLine("Conditions Number");
            outputStream.WriteLine(conditionsName.Count);
            foreach (var salida in conditionsName)
            {
                outputStream.WriteLine(salida);
            }
            outputStream.WriteLine("End Header");
        }

        internal void ReadFileHeader(System.IO.StreamReader inputStream)
        {
            bool end = false;
            while (!end)
            {
                string lector = inputStream.ReadLine();
                switch (lector)
                {
                    case "Version":
                        version = inputStream.ReadLine();
                        break;
                    case "Extracted":
                        extracted = bool.Parse(inputStream.ReadLine());
                        break;
                    case "Classified":
                        classified = bool.Parse(inputStream.ReadLine());
                        break;
                    case "Realigned":
                        realigned = bool.Parse(inputStream.ReadLine());
                        break;
                    case "Annotated":
                        annotated = bool.Parse(inputStream.ReadLine());
                        break;
                    case "Condition":
                        conditions = bool.Parse(inputStream.ReadLine());
                        break;
                    case "Start Codons Number":
                        int numStartCodons = int.Parse(inputStream.ReadLine());
                        startCodons = new List<string>();
                        for (int i = 0; i < numStartCodons; i++)
                        {
                            startCodons.Add(inputStream.ReadLine());
                        }
                        break;
                    case "Stop Codons Number":
                        int numStopCodons = int.Parse(inputStream.ReadLine());
                        stopCodons = new List<string>();
                        for (int i = 0; i < numStopCodons; i++)
                        {
                            stopCodons.Add(inputStream.ReadLine());
                        }
                        break;
                    case "Min length":
                        minLenght = int.Parse(inputStream.ReadLine());
                        break;
                    case "Max length":
                        maxLenght = int.Parse(inputStream.ReadLine());
                        break;
                    case "TA":
                        ta = double.Parse(inputStream.ReadLine());
                        break;
                    case "TB":
                        tb = double.Parse(inputStream.ReadLine());
                        break;
                    case "TC":
                        tc = double.Parse(inputStream.ReadLine());
                        break;
                    case "TD":
                        td = double.Parse(inputStream.ReadLine());
                        break;
                    case "Conservation Cutoff":
                        cutoff = double.Parse(inputStream.ReadLine());
                        break;
                    case "Genomefiles Number":
                        int genofilesCount = int.Parse(inputStream.ReadLine());
                        genomeFiles = new List<string>();
                        for (int i = 0; i < genofilesCount; i++)
                        {
                            genomeFiles.Add(inputStream.ReadLine());
                        }
                        break;
                    case "Index File":
                        indexFile = inputStream.ReadLine();
                        break;
                    case "Genome Folder":
                        genomeFolder = inputStream.ReadLine();
                        break;
                    case "Annotation Folder":
                        annotationFolder = inputStream.ReadLine();
                        break;
                    case "Conservation Folder":
                        conservationFolder = inputStream.ReadLine();
                        break;
                    case "Index Windows Size":
                        indexWindowSize = int.Parse(inputStream.ReadLine());
                        break;
                    case "Kozaks Number":
                        int numKozaks = int.Parse(inputStream.ReadLine());
                        kozaks = new List<string>();
                        for (int i = 0; i < numKozaks; i++)
                        {
                            kozaks.Add(inputStream.ReadLine());
                        }
                        break;
                    case "Bases to check":
                        basesToCheck = int.Parse(inputStream.ReadLine());
                        break;
                    case "Conservation Threshold":
                        conservationThreshold = float.Parse(inputStream.ReadLine());
                        break;
                    case "Conditions Number":
                        int numConditiona = int.Parse(inputStream.ReadLine());
                        conditionsName = new List<string>();
                        for (int i = 0; i < numConditiona; i++)
                        {
                            conditionsName.Add(inputStream.ReadLine());
                        }
                        break;
                    case "End Header":
                        end = true;
                        break;
                    default:

                        break;
                }
            }
        }
    }
}
