﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeneFinder.Models
{
    public class GroupReads
    {
        public List<AlignmentInstance> aligments { get; set; }
        public GroupReads()
        {
            aligments = new List<AlignmentInstance>();
        }
    }
}
